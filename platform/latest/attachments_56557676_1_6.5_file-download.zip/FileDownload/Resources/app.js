/* Create base UI tab and root window */
var win1 = Ti.UI.createWindow({  
    title: 'Photo Download',
    backgroundColor: '#fff'
});

/* Create a progress bar */
var progressBar = Ti.UI.createProgressBar({
	width: 200,
	height: 50,
	min: 0,
	max: 1,
	value: 0,
	style: Ti.UI.iOS.ProgressBarStyle.PLAIN,
	top: 10,
	message: 'Downloading image ...',
	font: { fontSize: 12, fontWeight: 'bold' },
	color: '#888'
});

win1.add(progressBar);
progressBar.show();

var image = Ti.UI.createImageView();
win1.add(image);

var xhr = Ti.Network.createHTTPClient({
	onload: function () {
		// first, grab a "handle" to the file where you'll store the downloaded data
		var file = Ti.Filesystem.getFile(Ti.Filesystem.applicationDataDirectory, 'cool_photo.jpg');
		file.write(this.responseData); // write to the file
		Ti.App.fireEvent('graphic_downloaded', { filepath: file.nativePath });
	},
	ondatastream: function (e) {
		progressBar.value = e.progress;
	},
	timeout: 10000
});
// image from http://www.flickr.com/photos/72213316@N00/3115485060/sizes/o/in/photostream/
xhr.open('GET', 'http://farm4.static.flickr.com/3244/3115485060_076a345932_o.jpg');
xhr.send();

Ti.App.addEventListener('graphic_downloaded', function (e) {
	progressBar.hide();
	image.image = e.filepath;
});