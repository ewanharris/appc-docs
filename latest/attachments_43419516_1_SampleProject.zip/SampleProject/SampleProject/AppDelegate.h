//
//  AppDelegate.h
//  SampleProject
//

#import <UIKit/UIKit.h>
#import <Appcelerator/Appcelerator.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
